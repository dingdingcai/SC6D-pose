This folder contains default detection/segmentation results that may be used by
object pose estimation methods participating in the BOP Challenge 2022. These
results were obtained by Mask R-CNN trained for CosyPose submissions to the BOP
Challenge 2020.

Two versions of detection/segmentation results are provided:

1) `cosypose_maskrcnn_pbr`: Results of Mask R-CNN trained only on the PBR
training images provided for the BOP Challenge 2020.

2) `cosypose_maskrcnn_synt+real`: Results of Mask R-CNN trained on the PBR
training images provided for the BOP Challenge 2020, custom CosyPose synthetic
training images (see the CosyPose paper for details), and real training images
(real training images are available only for some datasets).